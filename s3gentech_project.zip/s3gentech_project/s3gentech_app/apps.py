from django.apps import AppConfig


class S3GentechAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 's3gentech_app'
